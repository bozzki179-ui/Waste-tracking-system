<?php
session_start();
include "config.php";

// Check if admin is logged in
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}

// Handle form submission
$message = "";
if(isset($_POST['uid']) && isset($_POST['section'])){
    $uid = $conn->real_escape_string($_POST['uid']);
    $section = $conn->real_escape_string($_POST['section']);

    // Check if UID already exists
    $check = $conn->prepare("SELECT * FROM rfid_cards WHERE uid=? LIMIT 1");
    $check->bind_param("s",$uid);
    $check->execute();
    $result = $check->get_result();

    if($result->num_rows > 0){
        $message = "RFID UID already registered.";
    } else {
        $insert = $conn->prepare("INSERT INTO rfid_cards (uid, section, status) VALUES (?,?, 'active')");
        $insert->bind_param("ss", $uid, $section);
        if($insert->execute()){
            $message = "RFID registered successfully!";
        } else {
            $message = "Error: " . $insert->error;
        }
        $insert->close();
    }
    $check->close();
}

// Fetch sections for dropdown
$sections = $conn->query("SELECT section_name FROM sections");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Register RFID - Waste Tracking System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">

<div class="container" style="max-width:500px;">
    <div class="card shadow p-4">
        <h3 class="mb-3 text-center">Register RFID</h3>

        <?php if($message != ""): ?>
            <div class="alert alert-info"><?= $message ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="uid" class="form-control mb-3" placeholder="RFID UID" required>

            <select name="section" class="form-control mb-3" required>
                <option value="">Select Section</option>
                <?php while($row = $sections->fetch_assoc()): ?>
                    <option value="<?= $row['section_name'] ?>"><?= $row['section_name'] ?></option>
                <?php endwhile; ?>
            </select>

            <button type="submit" class="btn btn-primary w-100">Register RFID</button>
        </form>
    </div>
</div>

<!-- Bootstrap JS (optional for dropdowns/modals) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>