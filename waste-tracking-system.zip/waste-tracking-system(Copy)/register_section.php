<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}
include "config.php";

$message = "";

if(isset($_POST['section_name'])){
    $section_name = trim($_POST['section_name']); // remove whitespace

    if($section_name === "") {
        $message = "Section name cannot be empty!";
    } else {
        // Check if section already exists
        $stmt = $conn->prepare("SELECT * FROM sections WHERE section_name=?");
        $stmt->bind_param("s", $section_name);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows > 0){
            $message = "This section already exists!";
        } else {
            // Insert new section
            $stmt = $conn->prepare("INSERT INTO sections (section_name) VALUES (?)");
            $stmt->bind_param("s", $section_name);
            if($stmt->execute()){
                $message = "Section registered successfully!";
            } else {
                $message = "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register Section</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
<h3>Register New Section</h3>
<?php if($message!="") echo "<div class='alert alert-info'>$message</div>"; ?>
<form method="POST">
  <div class="mb-3">
    <label>Section Name</label>
    <input type="text" name="section_name" class="form-control" required>
  </div>
  <button class="btn btn-primary">Register Section</button>
</form>
<a href="admin.php" class="btn btn-secondary mt-2">Back to Dashboard</a>
</body>
</html>