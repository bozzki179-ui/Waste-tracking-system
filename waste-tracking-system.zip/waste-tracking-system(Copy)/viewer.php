<?php
session_start();
if(!isset($_SESSION['viewer'])){
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Viewer Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="p-4">
<h3>Viewer Dashboard</h3>

<div class="card p-3 mb-4">
<canvas id="chart"></canvas>
</div>

<div class="card p-3">
<h5>Recent Logs</h5>
<div id="logTable"></div>
</div>

<script>
const chartCtx = document.getElementById("chart").getContext("2d");
const chart = new Chart(chartCtx, {
    type: "bar",
    data: { labels: [], datasets: [{ label: "Usage", data: [], backgroundColor: "#28a745" }] },
    options: { responsive:true, plugins:{ legend:{ display:false } } }
});

function loadStats(){
    fetch("api/get_stats.php")
    .then(res => res.json())
    .then(data => {
        chart.data.labels = data.labels;
        chart.data.datasets[0].data = data.values;
        chart.update();
        document.getElementById("logTable").innerHTML = data.table;
    });
}

loadStats();
setInterval(loadStats,5000);
</script>
<a href="logout.php" class="btn btn-secondary mt-3">Logout</a>
</body>
</html>