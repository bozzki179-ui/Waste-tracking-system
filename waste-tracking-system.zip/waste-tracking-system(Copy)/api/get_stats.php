<?php
include "../config.php";

$sections = [];
$result = $conn->query("SELECT section_name FROM sections");
while($row = $result->fetch_assoc()){
    $sections[] = $row['section_name'];
}

$labels = [];
$values = [];
$tableHTML = "<table class='table table-bordered table-striped'><thead><tr><th>Section</th><th>Usage Count</th></tr></thead><tbody>";

foreach($sections as $sec){
    $labels[] = $sec;
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM logs WHERE section=?");
    $stmt->bind_param("s", $sec);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $values[] = $res['total'];
    $tableHTML .= "<tr><td>$sec</td><td>".$res['total']."</td></tr>";
    $stmt->close();
}
$tableHTML .= "</tbody></table>";

echo json_encode([
    "labels" => $labels,
    "values" => $values,
    "table"  => $tableHTML
]);

$conn->close();
?>