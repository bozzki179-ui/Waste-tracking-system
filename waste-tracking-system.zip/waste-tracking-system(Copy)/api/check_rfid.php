<?php
include "../config.php";
if(!isset($_GET['uid'])) { echo json_encode(["status"=>"inactive"]); exit(); }

$uid = $_GET['uid'];
$stmt = $conn->prepare("SELECT status FROM rfid_cards WHERE uid=? LIMIT 1");
$stmt->bind_param("s",$uid);
$stmt->execute();
$res = $stmt->get_result();

if($row = $res->fetch_assoc()){
    echo json_encode(["status"=>$row['status']]);
} else {
    echo json_encode(["status"=>"inactive"]);
}
$stmt->close();
$conn->close();
?>mt->bind_param("s", $uid);
$stmt->execute();
$stmt->store_result();

if($stmt->num_rows > 0){
    $stmt->bind_result($section);
    $stmt->fetch();

    // Insert log
    $insert = $conn->prepare("INSERT INTO logs(uid, section) VALUES (?, ?)");
    $insert->bind_param("ss", $uid, $section);
    $insert->execute();

    echo "GRANTED";

    // --- Email Alert ---
    require '../PHPMailer/PHPMailer.php';
    require '../PHPMailer/SMTP.php';
    require '../PHPMailer/Exception.php';

    $mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'bozzki179@gmail.com';         // replace with your Gmail
    $mail->Password = 'fzdr xzih vloi fnuv';           // replace with Gmail App Password
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('YOUR_EMAIL@gmail.com', 'Waste Tracking System');
    $mail->addAddress('ioniemariegmiasco@gmail.com'); // recipient
    $mail->Subject = "Bin Used in Section: $section";
    $mail->Body = "Bin was used by RFID UID: $uid in section: $section at ".date('Y-m-d H:i:s');

    try {
        $mail->send();
    } catch (Exception $e) {
        error_log("Mail Error: ".$mail->ErrorInfo);
    }

} else {
    echo "DENIED";
}
?>