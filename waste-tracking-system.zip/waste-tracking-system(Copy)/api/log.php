<?php
include "../config.php";

// Manually include PHPMailer from src folder
require '../vendor/phpmailer/src/PHPMailer.php';
require '../vendor/phpmailer/src/SMTP.php';
require '../vendor/phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if(!isset($_GET['uid'])) exit();

$uid = $_GET['uid'];

// Check if card is registered and active
$stmt = $conn->prepare("SELECT section FROM rfid_cards WHERE uid=? AND status='active' LIMIT 1");
$stmt->bind_param("s",$uid);
$stmt->execute();
$res = $stmt->get_result();

if($row = $res->fetch_assoc()){
    $section = $row['section'];

    // Insert log into database
    $stmt2 = $conn->prepare("INSERT INTO logs (uid, section, timestamp) VALUES (?,?,NOW())");
    $stmt2->bind_param("ss",$uid,$section);
    $stmt2->execute();
    $stmt2->close();

    // Send email alert
    $mail = new PHPMailer(true);
    try{
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'bozzki179@gmail.com';        // your email
        $mail->Password = 'fzdr xzih vloi fnuv';       // your app password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('bozzki179@gmail.com', 'Smart Trash Bin');
        $mail->addAddress('ioniemariegmiasco@gmail.com', 'Recipient');

        $mail->isHTML(true);
        $mail->Subject = "Bin Usage Log";
        $mail->Body = "Bin used by UID: $uid<br>Section: $section<br>Time: ".date('Y-m-d H:i:s');

        $mail->send();
    } catch (Exception $e){
        // Optional: log $mail->ErrorInfo
    }

    echo "Logged successfully";
} else {
    echo "Card inactive or not registered";
}

$stmt->close();
$conn->close();
?>