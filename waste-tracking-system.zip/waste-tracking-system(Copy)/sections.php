<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}
include "config.php";

// Fetch all sections
$sections = [];
$result = $conn->query("SELECT * FROM sections");
while($row = $result->fetch_assoc()){
    $sections[] = $row;
}

// Prepare data for chart
$labels = [];
$values = [];

foreach($sections as $sec){
    $labels[] = $sec['section_name'];
    // Count how many logs for this section
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM logs WHERE section=?");
    $stmt->bind_param("s", $sec['section_name']);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $values[] = $res['total'];
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Sections - Waste Tracking System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="p-4">

<h3>Sections</h3>
<table class="table table-bordered table-striped">
  <thead>
    <tr>
      <th>ID</th>
      <th>Section Name</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($sections as $sec){ ?>
      <tr>
        <td><?= $sec['id'] ?></td>
        <td><?= $sec['section_name'] ?></td>
      </tr>
    <?php } ?>
  </tbody>
</table>

<h4 class="mt-4">Bin Usage per Section</h4>
<div class="card p-3 mb-4">
  <canvas id="sectionChart"></canvas>
</div>

<a href="admin.php" class="btn btn-secondary mt-2">Back to Dashboard</a>

<script>
const ctx = document.getElementById('sectionChart').getContext('2d');
const sectionChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            label: 'Bin Usage',
            data: <?= json_encode($values) ?>,
            backgroundColor: '#2563eb'
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: true } },
        scales: { y: { beginAtZero: true, stepSize: 1 } }
    }
});
</script>

</body>
</html>