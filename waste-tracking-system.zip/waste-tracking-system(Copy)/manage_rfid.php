<?php
session_start();
include "config.php";
if(!isset($_SESSION['admin'])) header("Location: login.php");

// Toggle status
if(isset($_GET['uid'])){
    $uid = $_GET['uid'];
    $stmt = $conn->prepare("SELECT status FROM rfid_cards WHERE uid=? LIMIT 1");
    $stmt->bind_param("s", $uid);
    $stmt->execute();
    $res = $stmt->get_result();
    if($row = $res->fetch_assoc()){
        $newStatus = ($row['status']=='active') ? 'inactive' : 'active';
        $update = $conn->prepare("UPDATE rfid_cards SET status=? WHERE uid=?");
        $update->bind_param("ss",$newStatus,$uid);
        $update->execute();
        $update->close();
    }
    $stmt->close();
}

// Fetch all cards
$cards = $conn->query("SELECT uid, section, status FROM rfid_cards");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Manage RFID Cards</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4 bg-light">
<div class="d-flex">
<!-- Sidebar -->
<?php include 'sidebar.php'; ?> <!-- if you make sidebar a separate file -->
<!-- Main -->
<div class="flex-grow-1 p-4">
<h3>Manage RFID Cards</h3>
<table class="table table-bordered table-striped">
<thead>
<tr>
<th>UID</th>
<th>Section</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php while($row = $cards->fetch_assoc()): ?>
<tr>
<td><?= $row['uid'] ?></td>
<td><?= $row['section'] ?></td>
<td><?= $row['status'] ?></td>
<td>
<a href="manage_rfid.php?uid=<?= $row['uid'] ?>" class="btn btn-sm btn-primary">
<?= ($row['status']=='active') ? 'Deactivate' : 'Activate' ?>
</a>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>