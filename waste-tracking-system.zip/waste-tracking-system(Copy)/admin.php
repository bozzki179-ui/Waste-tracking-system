<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}
include "config.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Panel - Waste Tracking System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="d-flex">

<!-- Sidebar -->
<div class="bg-dark text-white p-3" style="width:250px; min-height:100vh;">
    <h5>Admin Panel</h5>
    <hr>
    <a href="admin.php" class="text-white d-block mb-2">Dashboard</a>
    <a href="sections.php" class="text-white d-block mb-2">Sections</a>
    <a href="register_section.php" class="text-white d-block mb-2">Register Section</a>
    <a href="register_rfid.php" class="text-white d-block mb-2">Register RFID</a>
    <a href="manage_rfid.php" class="text-white d-block mb-2">Manage RFID Cards</a>
    <a href="register_teacher.php" class="text-white d-block mb-2">Register Teacher / Viewer</a>
    <a href="logout.php" class="text-white">Logout</a>
</div>

<!-- Main content -->
<div class="flex-grow-1 p-4">
    <h3>Live Bin Usage Dashboard</h3>

    <!-- Chart -->
    <div class="card p-3 mb-4">
        <canvas id="sectionChart"></canvas>
    </div>

    <!-- Recent Logs -->
    <div class="card p-3">
        <h5>Recent Logs</h5>
        <div id="logTable"></div>
    </div>
</div>
</div>

<script>
// Load live stats for chart and logs
function loadStats(){
    fetch("api/get_stats.php")
    .then(res => res.json())
    .then(data => {
        sectionChart.data.labels = data.labels;
        sectionChart.data.datasets[0].data = data.values;
        sectionChart.update();
        document.getElementById("logTable").innerHTML = data.table;
    });
}

// Chart.js setup
const sectionChart = new Chart(document.getElementById("sectionChart"), {
    type: 'bar',
    data: {
        labels: [],
        datasets: [{
            label: 'Bin Usage',
            data: [],
            backgroundColor: '#2563eb'
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            title: { display: true, text: 'Bin Usage per Section' }
        }
    }
});

loadStats();
setInterval(loadStats, 5000); // Refresh every 5 seconds
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>