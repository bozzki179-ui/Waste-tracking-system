<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}

include "config.php";

$id = intval($_GET['id']);

$row = $conn->query("SELECT status FROM rfid_cards WHERE id=$id")->fetch_assoc();

$newStatus = ($row['status']=="active") ? "inactive" : "active";

$conn->query("
UPDATE rfid_cards 
SET status='$newStatus' 
WHERE id=$id
");

header("Location: admin.php");
exit();
?>