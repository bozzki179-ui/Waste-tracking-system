<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}
include "config.php";

$message = "";
if(isset($_POST['username'], $_POST['password'])){
    $username = trim($_POST['username']);
    $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
    $role = 'viewer'; // teacher/viewer role

    $stmt = $conn->prepare("INSERT INTO users (username,password,role) VALUES (?,?,?)");
    $stmt->bind_param("sss",$username,$password,$role);
    if($stmt->execute()){
        $message = "Teacher/Viewer registered successfully!";
    } else {
        $message = "Error: ".$stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register Teacher/Viewer</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
<h3>Register Teacher / Viewer</h3>
<?php if($message!="") echo "<div class='alert alert-info'>$message</div>"; ?>
<form method="POST">
  <div class="mb-3">
    <label>Username</label>
    <input type="text" name="username" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Password</label>
    <input type="password" name="password" class="form-control" required>
  </div>
  <button class="btn btn-primary">Register</button>
</form>
<a href="admin.php" class="btn btn-secondary mt-2">Back to Dashboard</a>
</body>
</html>